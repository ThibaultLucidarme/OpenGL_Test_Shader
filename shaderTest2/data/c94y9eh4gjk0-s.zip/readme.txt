Created by Herminio Nieves @2014
 for comercial and non comercial use.
includes everything you see,do not resale or bundle in
other packages.ormat in wavefront,see renders for refeence,if you use
Daz 3d you will be able to upload the product loaded with texures.remember
to decompress first then import the decompress file.
non movable parts.

Jesus Saves!